package pruebas;

import java.util.Scanner;
public class Prueba1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in); 
		//He quitado el punto en scanner.sc
		System.out.print("Introduce 1 o 0 en c, siendo 1 la palanca del juego activada y 0 apagada: ");
		int c = sc.nextInt();
		System.out.print("Introduce 1 o 0 en b, siendo 1 la palanca del juego activada y 0 apagada: ");
		int b = sc.nextInt();
		System.out.print("Introduce 1 o 0 en a, siendo 1 la palanca del juego activada y 0 apagada: ");
		int a = sc.nextInt(); 
		//He añadido prints para seleccionar c, b y a y quede más limpio en vez de ponerlos en una sola línea
		if (c==0) {
			if (b==0) {
				if (a==0) {
					System.out.println("Se ha quedado en la máquina");
				}
				else {
					System.out.println("Ha salido la canica por la máquina");
				}
			}
			else {
				if (a==0) {
					System.out.println("Ha salido la canica por la máquina");
				}
				else {
					System.out.println("Se ha quedado en la máquina");
				}
			}
		}
		else {
			if (b==0) {
				if (a==0) {
					System.out.println("Ha salido la canica por la máquina");
				}
				else {
					System.out.println("Se ha quedado en la máquina");
				}
			}
			else {
				if (a==0) {
					System.out.println("Se ha quedado en la máquina");
				}
				else {
					System.out.println("Ha salido la canica por la máquina");
				}
			}
		}
		sc.close();

	}

}
